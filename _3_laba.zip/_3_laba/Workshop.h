#pragma once

#include <string>
#include <vector>

#include "Car.h"
#include "Radio.h"

class Workshop {
public:
    Workshop();
    explicit Workshop(std::string address);
    Workshop(std::string address, std::vector<Radio> availableRadios);

    const std::string& getAddress() const;
    const std::vector<Radio>& getAvailableRadios() const;
    const std::vector<Car*>& getAttachedCars() const;

    void attachCar(Car* car);
    void installRadioToCar(const std::string& carRegNumber, const std::string& radioModel);

private:
    std::string address;
    std::vector<Radio> availableRadios;
    std::vector<Car*> attachedCars;
};
