#include "Car.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <random>
#include <stdexcept>

Car::Car()
    : brand("Porshe"), model("911"), bodyNumber("12312"), regNumber("F666FF"), mileage(100) {
}

Car::Car(const std::string& brand,
         const std::string& model,
         const std::string& bodyNumber,
         const std::string& regNumber,
         int mileage,
         std::vector<std::string> trunkItems)
    : brand(brand), model(model), mileage(mileage), trunkItems(std::move(trunkItems)) {
    setBodyNumber(bodyNumber);
    setRegNumber(regNumber);
}

Car::Car(const Car& other)
    : brand(other.brand), model(other.model), bodyNumber(other.bodyNumber), regNumber(other.regNumber),
      mileage(other.mileage), trunkItems(other.trunkItems) {
}

Car::~Car() {
    std::cout << "���������� Car ������" << std::endl;
}

std::string Car::getBrand() const { return brand; }
std::string Car::getModel() const { return model; }
std::string Car::getBodyNumber() const { return bodyNumber; }
std::string Car::getRegNumber() const { return regNumber; }
int Car::getMileage() const { return mileage; }
std::vector<std::string> Car::getTrunkItems() const { return trunkItems; }

void Car::setBodyNumber(const std::string& number) {
    if (number.length() != 6)
        throw std::invalid_argument("����� ������ ������ �������� �� 6 ��������");

    for (char c : number) {
        if (!std::isalnum(static_cast<unsigned char>(c)))
            throw std::invalid_argument("����� ������ ������ ��������� ������ ����� � �����");
    }

    bodyNumber = number;
}

void Car::setRegNumber(const std::string& number) {
    if (number.length() != 6)
        throw std::invalid_argument("�������� ������ ���� ������ 6 ��������");

    if (!std::isalpha(static_cast<unsigned char>(number[0])) ||
        !std::isdigit(static_cast<unsigned char>(number[1])) ||
        !std::isdigit(static_cast<unsigned char>(number[2])) ||
        !std::isdigit(static_cast<unsigned char>(number[3])) ||
        !std::isalpha(static_cast<unsigned char>(number[4])) ||
        !std::isalpha(static_cast<unsigned char>(number[5]))) {
        throw std::invalid_argument("�������� ������ ���� � ������� �555��");
    }

    regNumber = number;
}

void Car::addTrunkItem(const std::string& item) {
    trunkItems.push_back(item);
}

void Car::rollbackMileage(int x) {
    if (x <= 0)
        throw std::invalid_argument("����������� ������ ���� ������������� ������");

    if (mileage - x < 0)
        throw std::invalid_argument("������ �� ����� ���� �������������");

    mileage -= x;
}

void Car::printInfo() const {
    std::cout << "�����: " << brand << std::endl;
    std::cout << "������: " << model << std::endl;
    std::cout << "����� ������: " << bodyNumber << std::endl;
    std::cout << "���. �����: " << regNumber << std::endl;
    std::cout << "������: " << mileage << std::endl;
    std::cout << "�������� � ���������: ";
    if (trunkItems.empty()) {
        std::cout << "�����";
    } else {
        for (const auto& item : trunkItems) {
            std::cout << item << " ";
        }
    }
    std::cout << std::endl;

    if (hasRadio()) {
        std::cout << "���������: " << radio.model << " (" << radio.description << ") - " << radio.price << " ���." << std::endl;
    } else {
        std::cout << "���������: �� �����������" << std::endl;
    }
}

void Car::setRadio(const Radio& radio_) {
    radio = radio_;
}

const Radio& Car::getRadio() const {
    return radio;
}

bool Car::hasRadio() const {
    return !radio.isEmpty();
}

std::string Car::generateRandomRegNumber() {
    static const char letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static const char digits[] = "0123456789";
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> letterDist(0, 25);
    static std::uniform_int_distribution<> digitDist(0, 9);

    std::string result;
    result += letters[letterDist(gen)];
    result += digits[digitDist(gen)];
    result += digits[digitDist(gen)];
    result += digits[digitDist(gen)];
    result += letters[letterDist(gen)];
    result += letters[letterDist(gen)];

    return result;
}

Car Car::operator+(const Car& other) const {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> brandDist(0, 1);

    std::string newBrand = (brandDist(gen) == 0) ? brand : other.brand;
    std::string newRegNumber = generateRandomRegNumber();
    std::string newBodyNumber = bodyNumber.substr(0, 3) + other.bodyNumber.substr(3, 3);
    int newMileage = (mileage + other.mileage) / 2;
    std::string newModel = model + "+" + other.model;

    std::vector<std::string> newTrunkItems = trunkItems;
    newTrunkItems.insert(newTrunkItems.end(), other.trunkItems.begin(), other.trunkItems.end());
    std::sort(newTrunkItems.begin(), newTrunkItems.end());

    return Car(newBrand, newModel, newBodyNumber, newRegNumber, newMileage, newTrunkItems);
}

Car Car::operator-(const Car& other) const {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> brandDist(0, 1);

    std::string newBrand = (brandDist(gen) == 0) ? brand : other.brand;
    std::string newRegNumber = generateRandomRegNumber();
    std::string newBodyNumber = bodyNumber.substr(0, 3) + other.bodyNumber.substr(3, 3);
    int newMileage = std::abs(mileage - other.mileage);
    std::string newModel = (brandDist(gen) == 0) ? model : other.model;

    std::vector<std::string> newTrunkItems;

    for (const auto& item : trunkItems) {
        if (std::find(other.trunkItems.begin(), other.trunkItems.end(), item) == other.trunkItems.end()) {
            newTrunkItems.push_back(item);
        }
    }

    for (const auto& item : other.trunkItems) {
        if (std::find(trunkItems.begin(), trunkItems.end(), item) == trunkItems.end()) {
            newTrunkItems.push_back(item);
        }
    }

    std::sort(newTrunkItems.begin(), newTrunkItems.end());

    return Car(newBrand, newModel, newBodyNumber, newRegNumber, newMileage, newTrunkItems);
}

Car Car::operator/(const Car& other) const {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> brandDist(0, 1);

    std::string newBrand = (brandDist(gen) == 0) ? brand : other.brand;
    std::string newRegNumber = generateRandomRegNumber();
    std::string newBodyNumber = bodyNumber.substr(0, 3) + other.bodyNumber.substr(3, 3);
    int newMileage = (other.mileage != 0) ? mileage / other.mileage : mileage;
    std::string newModel = model + "/" + other.model;

    std::vector<std::string> newTrunkItems;

    for (const auto& item : trunkItems) {
        if (std::find(other.trunkItems.begin(), other.trunkItems.end(), item) != other.trunkItems.end() &&
            std::find(newTrunkItems.begin(), newTrunkItems.end(), item) == newTrunkItems.end()) {
            newTrunkItems.push_back(item);
        }
    }

    std::sort(newTrunkItems.begin(), newTrunkItems.end());

    return Car(newBrand, newModel, newBodyNumber, newRegNumber, newMileage, newTrunkItems);
}
